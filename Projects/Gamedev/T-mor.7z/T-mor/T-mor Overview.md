#gamedev #sinco #t-mor #nicom #li-sut #macohi-and-lathol 

# Overview

T-mor is a merging of all of my current stories and their variations.

The main stories that came to mind:
- [Sinco (2025 Remake)](../../Stories/Pre-T-mor/Sinco/Sinco%20(2025%20Remake).md)
- [Sinco Retold](../../Stories/Pre-T-mor/Sinco/Sinco%20Retold.md)

- [Nicom (OG)](../../Stories/Pre-T-mor/Nicom/Nicom%20(OG).md)
- [Nicom (Hero X Villain)](../../Stories/Pre-T-mor/Nicom/Nicom%20(Hero%20X%20Villain).md)
- [Nicom (Goddesses)](../../Stories/Pre-T-mor/Nicom/Nicom%20(Goddesses).md)

- [Li Sut](../../Stories/Pre-T-mor/Li%20Sut.md)

- [Macohi and Lathol](../../Stories/Pre-T-mor/Macohi%20and%20Lathol.md)

Additional stories:
- [Portilizen](../../Portilizen.md)

# Links

N / A 