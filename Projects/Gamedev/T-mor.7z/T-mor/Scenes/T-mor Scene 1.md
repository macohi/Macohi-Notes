#t-mor #sinco

# Intro Cutscene

The environment is a metallic room with a lot of space.

[Sinco](../../../../Others/Characters/Sinco%20Series/Sinco.md) and [Tirok](../../../../Others/Characters/Sinco%20Series/Tirok/Tirok.md) from [Sinco (2025 Remake)](../../../Stories/Pre-T-mor/Sinco/Sinco%20(2025%20Remake).md) are in a conflict.

Sinco is attempting to reach Tirok who's sabotaging Sinco's attempts at getting closer to stop Tirok's console from launching his [Universe Merging Machine](../../../../Others/Characters/Sinco%20Series/Tirok/Universe%20Merging%20Machine.md).

Right as Sinco reaches the console to turn it off, a blinding flash of light explodes from the console, sending Sinco away and absorbing Sinco.

# Part

***

Part 1

Part 1 gameplay consists of Sinco trying to survive the initial attempt at universes merging.

You have to survive for 1 - 2 minutes. Avoiding debris from Tirok's now destroyed lab that randomly appears from up or down.
