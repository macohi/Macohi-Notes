#t-mor 

The production plan for T-mor consists of videos on new content coming before the release including the content.

Example:

- New Level Pack Begins Production
- Part 1 of the Level Pack is finished
- Part 1 of the Level Pack has a video released

And the same would happen for the other parts

Cutscenes come later or for special occasions.